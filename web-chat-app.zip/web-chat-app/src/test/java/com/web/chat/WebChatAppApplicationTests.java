package com.web.chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebChatAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
